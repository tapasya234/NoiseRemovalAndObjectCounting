/*
Author: Tapasya Gutta
File: Part3
Description: This is the 1st part of the Assignment 2 of Video Analytics
In this part, a new image needs to be created by adding gaussian noise 
of sigma = 0.5 to it and write code to remove the noise

Reference: http://www.docs.opencv.org/2.4/doc/tutorials/core/basic_linear_transform/basic_linear_transform.html
*/

#include<iostream>
#include<conio.h>
#include<math.h>

#include<opencv2/core/core.hpp>
#include<opencv2/highgui/highgui.hpp>
#include<opencv2/imgproc/imgproc.hpp>

using namespace std;
using namespace cv;

/*
void add_gaussian_Noise(Mat &srcArr, double sigma)
{
	Mat NoiseArr = srcArr.clone();
	RNG rng;
	//rng.fill(NoiseArr, RNG::NORMAL, mean, sigma);

	//randn(dstArr,mean,sigma); 
	add(srcArr, NoiseArr, srcArr);
	for (int y = 0; y < srcArr.rows; y++)
	{
		for (int x = 0; x < srcArr.cols; x++)
		{
			double noise = rng.gaussian(sigma);

			for (int c = 0; c < 3; c++)
			{

				srcArr.at<Vec3b>(y, x)[c] =
					saturate_cast<uchar>((srcArr.at<Vec3b>(y, x)[c]) + noise);
			}
		}
	}
}

void remove_gaussian_noise(Mat &src)
{
	for (int y = 1; y < src.rows - 1; y++) {
		for (int x = 1; x < src.cols - 1; x++) {
			Vec3b one = src.at<Vec3b>(y - 1, x - 1);
			Vec3b two = src.at<Vec3b>(y, x - 1);
			Vec3b three = src.at<Vec3b>(y + 1, x - 1);
			Vec3b four = src.at<Vec3b>(y - 1, x);
			Vec3b five = src.at<Vec3b>(y, x);
			Vec3b six = src.at<Vec3b>(y + 1, x);
			Vec3b seven = src.at<Vec3b>(y - 1, x + 1);
			Vec3b eight = src.at<Vec3b>(y, x + 1);
			Vec3b nine = src.at<Vec3b>(y + 1, x + 1);
			Vec3b& org = src.at<Vec3b>(y, x);
			for (int c = 0; c < 3; c++)
			{
				double value = (one[c] + (two[c] * 2) + three[c] + (four[c] * 2) + (five[c]) + (six[c] * 2) + seven[c] + (eight[c] * 2) + nine[c]) / 16;
				org[c] = value;

			}
		}
	}
}
*/

cv::Mat addGaussianNoise(cv :: Mat imgOrg) {

	cv::Mat noisyImg = cv::Mat::zeros(imgOrg.size(), imgOrg.type());

	double stdDev = 0.5;
	//double var = stdDev * stdDev;
	//double pi = 3.141592653589;
	
	cv::Mat gNoise = cv::Mat(imgOrg.size(), CV_16SC3);
	randn(gNoise, Scalar::all(0), Scalar::all(stdDev));
	
	
	for (int y = 0; y < imgOrg.rows; y++) {
		for (int x = 0; x < imgOrg.cols; x++) {
			Vec3b pixel = imgOrg.at<Vec3b>(y, x);
			Vec3s noise = gNoise.at<Vec3s>(y, x);
			Vec3b newPixel;

			for (int i = 0; i < 3; i++)
			{
				newPixel.val[i] = pixel.val[i] + noise.val[i];
				newPixel.val[i] = newPixel.val[i] > 255 ? 255 : newPixel.val[i];
				newPixel.val[i] = newPixel.val[i] < 0 ? 0 : newPixel.val[i];

			}

			noisyImg.at<Vec3b>(y, x) = newPixel;
		}
	}
	return noisyImg;
}

cv::Mat filterImage(cv::Mat imgOrg) {

	cv::Mat denoised = cv::Mat::zeros(imgOrg.size(), imgOrg.type());

	//int mean = 0;
	double stdDev = 0.5;
	double var = stdDev * stdDev;
	double pi = 3.141592653589;
	double e = 2.718;

	double mask[5][5] = { {0.003, 0.013, 0.022, 0.013, 0.003},
						  {0.013, 0.059, 0.097, 0.059, 0.013},
						  {0.022, 0.097, 0.159, 0.097, 0.022},
						  {0.013, 0.059, 0.097, 0.059, 0.013},
						  {0.003, 0.013, 0.022, 0.013, 0.003} };

	for (int y = 2; y < imgOrg.rows-2; y++) {
		for (int x = 2; x < imgOrg.cols-2; x++) {
			for (int c = 0; c < imgOrg.channels(); c++) {
				//int pixel = imgOrg.at<Vec3b>(y, x)[c];
				denoised.at<Vec3b>(y, x)[c] = (0.003 * imgOrg.at<Vec3b>(y - 2, x - 2)[c]) + 
											(0.013 * imgOrg.at<Vec3b>(y - 2, x - 1)[c]) +
											(0.022 * imgOrg.at<Vec3b>(y - 2, x)[c]) + 				  
											(0.013 * imgOrg.at<Vec3b>(y - 2, x + 1)[c]) + 
											(0.003 * imgOrg.at<Vec3b>(y - 2, x + 2)[c]) +
											
											(0.013 * imgOrg.at<Vec3b>(y - 1, x - 2)[c]) +
											(0.059 * imgOrg.at<Vec3b>(y - 1, x - 1)[c]) + 
											(0.097 * imgOrg.at<Vec3b>(y - 1, x)[c]) +
											(0.059 * imgOrg.at<Vec3b>(y - 1, x)[c]) + 
											(0.013 * imgOrg.at<Vec3b>(y - 1, x + 1)[c]) + 

											(0.022 * imgOrg.at<Vec3b>(y - 1, x + 2)[c]) +
											(0.097 * imgOrg.at<Vec3b>(y, x - 2)[c]) + 
											(0.159 * imgOrg.at<Vec3b>(y, x - 1)[c]) + 
											(0.097 * imgOrg.at<Vec3b>(y, x)[c]) +
											(0.022 * imgOrg.at<Vec3b>(y, x + 1)[c]) + 
					
											(0.013 * imgOrg.at<Vec3b>(y, x + 2)[c]) + 
											(0.059 * imgOrg.at<Vec3b>(y + 1, x - 2)[c]) +
											(0.097 * imgOrg.at<Vec3b>(y + 1, x - 1)[c]) + 
											(0.059 * imgOrg.at<Vec3b>(y + 1, x)[c]) + 
											(0.013 * imgOrg.at<Vec3b>(y + 1, x + 1)[c]) +
					
											(0.003 * imgOrg.at<Vec3b>(y + 1, x + 2)[c]) + 
											(0.013 * imgOrg.at<Vec3b>(y + 2, x - 2)[c]) + 
											(0.022 * imgOrg.at<Vec3b>(y + 2, x + 1)[c]) +
											(0.013 * imgOrg.at<Vec3b>(y + 2, x)[c]) + 
											(0.003 * imgOrg.at<Vec3b>(y + 2, x + 2)[c]);

				
			}
			//Vec3b pixel = imgOrg.at<Vec3b>(y, x);
			
			/*double power = (x*x + y*y) / (2 * var);
			double denom = 2 * pi * var;
			double g = (1 / denom) *  pow(e, -1 * power);
			pixel.val[0] = g;
			pixel.val[1] = g;
			pixel.val[2] = g;
			
			denoised.at<Vec3b>(y, x) = pixel;*/

		}
	}
	return denoised;
}

int main() {
	cv::Mat imgOriginal;        // input image
	imgOriginal = cv::imread("image.jpg");          // open image

	if (imgOriginal.empty()) {                                  // if unable to open image
		std::cout << "error: image not read from file\n\n";     // show error message on command line
		_getch();                                               
		return(0);                                              // and exit program
	}

	cv::Mat noisyImage = cv::Mat::zeros(imgOriginal.size(), imgOriginal.type());
	noisyImage = addGaussianNoise(imgOriginal);

	cv::Mat deNoisedImage = cv::Mat::zeros(imgOriginal.size(), imgOriginal.type());
	deNoisedImage = filterImage(noisyImage);
	

	// creating windows
	cv::namedWindow("Original Image", CV_WINDOW_AUTOSIZE);     
	cv::namedWindow("Noisy Image", CV_WINDOW_AUTOSIZE);        
	cv::namedWindow("DeNoised Image", CV_WINDOW_AUTOSIZE); 

	// show windows
	cv::imshow("Original Image", imgOriginal);     
	cv::imshow("Noisy Image", noisyImage);
	cv::imshow("DeNoised Image", deNoisedImage);

	// Saving the new image
	cv::imwrite("gaussianNoiseImage.jpg", noisyImage);
	cv::imwrite("gaussianDenoised.jpg", deNoisedImage);

	/*add_gaussian_Noise(imgOriginal, 0.5);
	cv::imshow("Noisy Image", imgOriginal);
	remove_gaussian_noise(imgOriginal);
	cv::imshow("DeNoised Image", imgOriginal); */


	cv::waitKey(0);              // hold windows open until user presses a key
	return(0);
}
