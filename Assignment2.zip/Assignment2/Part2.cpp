/*
Author: Tapasya Gutta
File: Part3
Description: This is the 2nd part of the Assignment 2 of Video Analytics
In this part, a new image needs to be created by adding gaussian noise
of sigma = 0.5 to it and write code to remove the noise

Reference: Pg. 25 of A Practical Introduction to Computer Vision with OpenCV
Reference: http://homepages.inf.ed.ac.uk/rbf/HIPR2/median.htm
Reference: https://en.wikipedia.org/wiki/Median_filter
*/

#include<iostream>
#include<conio.h>
#include<math.h>

#include<opencv2/core/core.hpp>
#include<opencv2/highgui/highgui.hpp>
#include<opencv2/imgproc/imgproc.hpp>

using namespace std;
using namespace cv;

cv::Mat addSaltPepperNoise(cv::Mat imgOrg) {

	cv::Mat noisyImg = imgOrg.clone();

	double noisePercentage = 2;
	int rows = imgOrg.rows;
	int columns = imgOrg.cols;
	int channels = imgOrg.channels();

	int nPoints = (int)(((double)rows * columns * channels) * noisePercentage / 100);

	for (int count = 0; count < nPoints; count++) {
		int row = rand() % rows;
		int column = rand() % columns;
		int channel = rand() % channels;

		Vec3b pixel = imgOrg.at<Vec3b>(row, column);
		if (rand() % 2 == 1) {
			pixel.val[0] = 255;
			pixel.val[1] = 255;
			pixel.val[2] = 255;
			//pixel.val[channel] = 255;
		}
		else {
			pixel.val[0] = 0;
			pixel.val[1] = 0;
			pixel.val[2] = 0;
			//pixel.val[channel] = 0;
		}

		noisyImg.at<Vec3b>(row, column) = pixel;
	}

	return noisyImg;
}

int findMedian(int list[], int length) {
	int median = 0;
	int j, temp;

	for (int i = 0; i < length; i++) {
		j = i;
		while (j > 0 && list[j] < list[j - 1]) {
			temp = list[j];
			list[j] = list[j - 1];
			list[j - 1] = temp;
			j--;
		}
	}
	
	if (length % 2 == 0) {
		int a = length / 2;
		median = (int)((list[a] + list[a-1]) / 2);
	}
	else {
		int a = length / 2;
		median = list[a];
	}

	return median;
}
cv::Mat filterImage(cv::Mat imgOrg) {

	cv::Mat denoisedImg = cv::Mat::zeros(imgOrg.size(), imgOrg.type());

	for (int y = 0; y < imgOrg.rows; y++) {
		for (int x = 0; x < imgOrg.cols; x++) {
			for (int c = 0; c < imgOrg.channels(); c++) {
				int pixel = imgOrg.at<Vec3b>(y, x)[c];
				
				if (y == 0) {
					if(x == 0) {
						int list[4] = { imgOrg.at<Vec3b>(y, x)[c],
							imgOrg.at<Vec3b>(y, x + 1)[c], imgOrg.at<Vec3b>(y + 1, x)[c],
							imgOrg.at<Vec3b>(y + 1, x + 1)[c] };
						pixel = findMedian(list, 4);
					}
					else if (x == imgOrg.cols - 1) {
						int list[4] = { imgOrg.at<Vec3b>(y , x - 1)[c],
							imgOrg.at<Vec3b>(y, x)[c], imgOrg.at<Vec3b>(y + 1, x - 1)[c] ,
							imgOrg.at<Vec3b>(y + 1, x)[c] };
						pixel = findMedian(list, 4);
					}
					else {
						int list[6] = { imgOrg.at<Vec3b>(y, x - 1)[c],
							imgOrg.at<Vec3b>(y, x)[c], imgOrg.at<Vec3b>(y , x + 1)[c],
							imgOrg.at<Vec3b>(y + 1, x - 1)[c], imgOrg.at<Vec3b>(y + 1 , x)[c],
							imgOrg.at<Vec3b>(y + 1 , x + 1)[c] };
						pixel = findMedian(list, 6);
					}
				}

				else if (y == imgOrg.rows - 1) {
					if(x == 0) {
						int list[4] = { imgOrg.at<Vec3b>(y - 1, x)[c],
							imgOrg.at<Vec3b>(y - 1, x + 1)[c], imgOrg.at<Vec3b>(y , x)[c],
							imgOrg.at<Vec3b>(y, x + 1)[c] };
						pixel = findMedian(list, 4);
					}
					else if (x == imgOrg.cols - 1) {
						int list[4] = { imgOrg.at<Vec3b>(y - 1, x - 1)[c],
							imgOrg.at<Vec3b>(y - 1, x)[c], imgOrg.at<Vec3b>(y , x - 1)[c] ,
							imgOrg.at<Vec3b>(y, x)[c] };
						pixel = findMedian(list, 4);
					}
					else {
						int list[6] = { imgOrg.at<Vec3b>(y - 1, x - 1)[c],
							imgOrg.at<Vec3b>(y - 1, x)[c], imgOrg.at<Vec3b>(y - 1 , x + 1)[c],
							imgOrg.at<Vec3b>(y, x - 1)[c], imgOrg.at<Vec3b>(y , x)[c],
							imgOrg.at<Vec3b>(y , x + 1)[c] };
						pixel = findMedian(list, 6);
					}
				}
				
				else if (x == 0 && (y != 0 || y != imgOrg.rows-1)) {
					int list[6] = { imgOrg.at<Vec3b>(y - 1, x)[c],
						imgOrg.at<Vec3b>(y - 1, x + 1)[c], imgOrg.at<Vec3b>(y , x)[c],
						imgOrg.at<Vec3b>(y, x + 1)[c], imgOrg.at<Vec3b>(y + 1 , x)[c],
						imgOrg.at<Vec3b>(y + 1 , x + 1)[c] };
					pixel = findMedian(list, 6);
				}
				else if (x == imgOrg.cols - 1 && (y != 0 || y != imgOrg.rows - 1)) {
					int list[6] = { imgOrg.at<Vec3b>(y - 1, x - 1)[c],
						imgOrg.at<Vec3b>(y - 1, x)[c], imgOrg.at<Vec3b>(y , x - 1)[c],
						imgOrg.at<Vec3b>(y, x)[c], imgOrg.at<Vec3b>(y + 1 , x - 1)[c],
						imgOrg.at<Vec3b>(y + 1 , x)[c] };
					pixel = findMedian(list, 6);
				} 

				else {
					int list[9] = { imgOrg.at<Vec3b>(y - 1, x - 1)[c], 
						imgOrg.at<Vec3b>(y - 1, x)[c] , imgOrg.at<Vec3b>(y - 1, x + 1)[c] ,
						imgOrg.at<Vec3b>(y, x - 1)[c] , imgOrg.at<Vec3b>(y, x)[c] , 
						imgOrg.at<Vec3b>(y, x + 1)[c] , imgOrg.at<Vec3b>(y + 1, x - 1)[c] , 
						imgOrg.at<Vec3b>(y + 1, x)[c] , imgOrg.at<Vec3b>(y + 1, x + 1)[c] };
					pixel = findMedian(list, 9);
				} 

				denoisedImg.at<Vec3b>(y, x)[c] = pixel;
			}
		}
	}

	return denoisedImg;

}

int main() {
	cv::Mat imgOriginal;        // input image
	imgOriginal = cv::imread("image.jpg");          // open image

	if (imgOriginal.empty()) {                                  // if unable to open image
		std::cout << "error: image not read from file\n\n";     // show error message on command line
		_getch();
		return(0);                                              // and exit program
	}

	cv::Mat noisyImage = cv::Mat::zeros(imgOriginal.size(), imgOriginal.type());
	cv::Mat deNoisedImage = cv::Mat::zeros(imgOriginal.size(), imgOriginal.type());
	noisyImage = addSaltPepperNoise(imgOriginal);
	deNoisedImage = filterImage(noisyImage);

	// creating windows
	cv::namedWindow("Original Image", CV_WINDOW_AUTOSIZE);     
	cv::namedWindow("Noisy Image", CV_WINDOW_AUTOSIZE);        
	cv::namedWindow("DeNoised Image", CV_WINDOW_AUTOSIZE);
	
	// show windows
	cv::imshow("Original Image", imgOriginal);     
	cv::imshow("Noisy Image", noisyImage);
	cv::imshow("DeNoised Image", deNoisedImage);

	// Saving the new image
	imwrite("saltPepperNoiseImage.jpg", noisyImage);
	imwrite("spDenoised.jpg", deNoisedImage);

	cv::waitKey(0);              // hold windows open until user presses a key
	return(0);
}
