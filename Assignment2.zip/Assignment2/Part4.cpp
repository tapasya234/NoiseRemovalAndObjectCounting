/*
Author: Tapasya Gutta
File: Part3
Description: This is the 4th part of the Assignment 2 of Video Analytics
In this part, we need to count the number of apples in different images

Reference: http://www.docs.opencv.org/2.4/doc/tutorials/core/basic_linear_transform/basic_linear_transform.html
*/

#include<iostream>
#include<conio.h>
#include<math.h>

#include<opencv2/core/core.hpp>
#include<opencv2/highgui/highgui.hpp>
#include<opencv2/imgproc/imgproc.hpp>

using namespace std;
using namespace cv;

int main() {

	cv::Mat img[6];								// input images
	img[0] = cv::imread("image.jpg");          // original image
	img[1] = cv::imread("gaussianNoiseImage.jpg");          // gaussian noisy image
	img[2] = cv::imread("gaussianDenoised.jpg");          // gaussian denoised image
	img[3] = cv::imread("saltPepperNoiseImage.jpg");          // salt and papper noisy image
	img[4] = cv::imread("spDenoised.jpg");          // salt and pepper denoised image
	img[5] = cv::imread("brightenedImage.jpg");          // brightened image


	if (img[0].empty() || img[0].empty() || img[0].empty() || 
		img[0].empty() || img[0].empty() || img[0].empty()) {   //if unable to open image
		std::cout << "error: image not read from file\n\n";     // show error message on command line
		_getch();
		return(0);                                              // and exit program
	}

	
	for (int i = 0; i < 6; i++) {

		// to binary
		cv::Mat hsvImage;
		cv::cvtColor(img[i], hsvImage, CV_BGR2HSV);

		// to binary
		cv::Mat redImg = cv::Mat::zeros(img[i].size(), img[i].type());
		cv::Mat redImg1 = cv::Mat::zeros(img[i].size(), img[i].type());
		cv::Mat redImg2 = cv::Mat::zeros(img[i].size(), img[i].type());
		cv::Mat greenImg = cv::Mat::zeros(img[i].size(), img[i].type());

		cv::inRange(hsvImage, cv::Scalar(0, 100, 100), cv::Scalar(15, 255, 255), redImg1);
		cv::inRange(hsvImage, cv::Scalar(155, 100, 100), cv::Scalar(179, 255, 255), redImg2);
		cv::inRange(hsvImage, cv::Scalar(30, 100, 100), cv::Scalar(90, 255, 255), greenImg);
		cv::addWeighted(redImg1, 1.0, redImg2, 1.0, 0.0, redImg);
		cv::addWeighted(redImg, 1.0, greenImg, 1.0, 0.0, img[i]);
	}


	// DILATION and EROTION
	int dilation_type = MORPH_CROSS;
	Size appleStruct = Size(9.5, 9.5);
	Point anchor = Point(-1, -1);
	Mat structElementD = getStructuringElement(dilation_type, appleStruct, anchor);
	Size appleStructE = Size(9.5, 9.5);
	Mat structElementE = getStructuringElement(dilation_type, appleStructE, anchor);
	
	cv::Mat dilatedImg[6];
	cv::Mat erodedImg[6];
	for (int i = 0; i < 6; i++) {
		dilate(img[i], dilatedImg[i], structElementD);
		erode(dilatedImg[i], erodedImg[i], structElementE);
	}

	//COUNTING APPLES
	vector<vector<Point> > contours;
	vector<Vec4i> hierarchy;
	findContours(dilatedImg[0], contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE); // finds contours on bin image
	//findContours(erodedImg[0], contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);
	cout << "Original Image: " << contours.size() << endl;
	
	findContours(dilatedImg[1], contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);
	//findContours(erodedImg[1], contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);
	cout << "Gaussian Noise Image: " << contours.size() << endl;

	findContours(dilatedImg[2], contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);
	//findContours(erodedImg[2], contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);
	cout << "Gaussian DeNoise Image: " << contours.size() << endl;

	findContours(dilatedImg[3], contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);
	//findContours(erodedImg[3], contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);
	cout << "Salt and Pepper Noise Image: " << contours.size() << endl;

	findContours(dilatedImg[4], contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);
	//findContours(erodedImg[4], contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);
	cout << "Salt and Pepper DeNoise Image: " << contours.size() << endl;

	findContours(dilatedImg[5], contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);
	//findContours(erodedImg[5], contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);
	cout << "Brightened Image: " << contours.size() << endl;

	// creating windows
	cv::namedWindow("Original Image", CV_WINDOW_AUTOSIZE);
	cv::namedWindow("Gaussian Noisy Image", CV_WINDOW_AUTOSIZE);
	cv::namedWindow("Gaussian DeNoised Image", CV_WINDOW_AUTOSIZE);
	cv::namedWindow("Salt and Pepper Noisy Image", CV_WINDOW_AUTOSIZE);
	cv::namedWindow("Salt and Pepper DeNoised Image", CV_WINDOW_AUTOSIZE);
	cv::namedWindow("Brightened Image", CV_WINDOW_AUTOSIZE);
	cv::namedWindow("Structuring Element", CV_WINDOW_AUTOSIZE); 
	

	// show windows
	cv::imshow("Original Image", erodedImg[0]);
	cv::imshow("Gaussian Noisy Image", erodedImg[1]);
	cv::imshow("Gaussian DeNoised Image", erodedImg[2]);
	cv::imshow("Salt and Pepper Noisy Image", erodedImg[3]);
	cv::imshow("Salt and Pepper DeNoised Image", erodedImg[4]);
	cv::imshow("Brightened Image", erodedImg[5]);


	// Saving the new image
	imwrite("binary_Original.jpg", img[0]);
	imwrite("binary_GNoisy.jpg", img[1]);
	imwrite("binary_GDenoised.jpg", img[2]);
	imwrite("binary_SPNoisy.jpg", img[3]);
	imwrite("binary_SPDenoised.jpg", img[4]);
	imwrite("binary_Brightened.jpg", img[5]);

	cv::waitKey(0);              // hold windows open until user presses a key
	return(0);
}